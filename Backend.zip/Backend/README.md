# Book IR (Information Retrieval)

This script uses TF-IDF and Cosine Similarity to retrieve the top 3 most relevant passages from a 120-page book, based on user queries.

## Files

- `book_ir.py`: Main script with a command-line interface and callable `search_book()` function.
- `book_chunks.pkl`: Pre-processed and chunked book data (about 500 characters per chunk).
- `requirements.txt`: Python dependencies.
- `.gitignore`: Ignores unnecessary files such as virtual environments.

## Usage

1. Make sure Python 3 is installed.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the script:

```bash
python book_ir.py
```

4. Enter natural language queries when prompted. Type `exit` to quit.

## Integration

You can import the search logic into any Python app (like Django):

```python
from book_ir import search_book

results = search_book("What does the book say about forgiveness?")
```
